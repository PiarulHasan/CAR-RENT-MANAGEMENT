-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema car_rent
--

CREATE DATABASE IF NOT EXISTS car_rent;
USE car_rent;

--
-- Definition of table `campanypayment`
--

DROP TABLE IF EXISTS `campanypayment`;
CREATE TABLE `campanypayment` (
  `paymentid` int(10) unsigned NOT NULL auto_increment,
  `companyid` int(10) unsigned NOT NULL,
  `payamount` double NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  USING BTREE (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campanypayment`
--

/*!40000 ALTER TABLE `campanypayment` DISABLE KEYS */;
/*!40000 ALTER TABLE `campanypayment` ENABLE KEYS */;


--
-- Definition of table `carcompany`
--

DROP TABLE IF EXISTS `carcompany`;
CREATE TABLE `carcompany` (
  `companyid` int(10) unsigned NOT NULL auto_increment,
  `catid` int(10) unsigned NOT NULL,
  `companyname` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` decimal(10,0) NOT NULL,
  `price` double NOT NULL,
  `email` varchar(75) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  USING BTREE (`companyid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carcompany`
--

/*!40000 ALTER TABLE `carcompany` DISABLE KEYS */;
/*!40000 ALTER TABLE `carcompany` ENABLE KEYS */;


--
-- Definition of table `cardetails`
--

DROP TABLE IF EXISTS `cardetails`;
CREATE TABLE `cardetails` (
  `carid` int(10) unsigned NOT NULL auto_increment,
  `catid` int(10) unsigned NOT NULL,
  `brand` varchar(45) NOT NULL,
  `model` varchar(45) NOT NULL,
  `rentprice` double NOT NULL,
  `image` varchar(45) NOT NULL,
  `colour` varchar(45) NOT NULL,
  `fuel` varchar(45) NOT NULL,
  `mileage` decimal(10,0) NOT NULL,
  `cartype` varchar(45) NOT NULL,
  `carcategory` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  USING BTREE (`carid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cardetails`
--

/*!40000 ALTER TABLE `cardetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `cardetails` ENABLE KEYS */;


--
-- Definition of table `cardriver`
--

DROP TABLE IF EXISTS `cardriver`;
CREATE TABLE `cardriver` (
  `driverid` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `phone` decimal(10,0) NOT NULL,
  `licenseno` decimal(10,0) NOT NULL,
  `expyear` decimal(10,0) NOT NULL,
  `location` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  USING BTREE (`driverid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cardriver`
--

/*!40000 ALTER TABLE `cardriver` DISABLE KEYS */;
/*!40000 ALTER TABLE `cardriver` ENABLE KEYS */;


--
-- Definition of table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `catid` varchar(45) NOT NULL,
  `catname` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  PRIMARY KEY  (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`catid`,`catname`,`description`) VALUES 
 ('1','Car','Private Car'),
 ('2','Microbus','Hayice Car'),
 ('3','Car','Probox Car');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Definition of table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `custmoerid` int(10) unsigned NOT NULL auto_increment,
  `carid` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `phone` decimal(10,0) NOT NULL,
  `email` varchar(75) NOT NULL,
  `location` varchar(45) NOT NULL,
  `bookingdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `rentprice` double NOT NULL,
  `paymentmode` varchar(45) NOT NULL,
  `payment` double NOT NULL,
  `driveroption` varchar(45) NOT NULL,
  PRIMARY KEY  USING BTREE (`custmoerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


--
-- Definition of table `driverpayment`
--

DROP TABLE IF EXISTS `driverpayment`;
CREATE TABLE `driverpayment` (
  `paymentid` int(10) unsigned NOT NULL auto_increment,
  `driverid` int(10) unsigned NOT NULL,
  `payamount` double NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  USING BTREE (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driverpayment`
--

/*!40000 ALTER TABLE `driverpayment` DISABLE KEYS */;
/*!40000 ALTER TABLE `driverpayment` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `emailid` varchar(45) NOT NULL,
  `uname` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  PRIMARY KEY  USING BTREE (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
CREATE TABLE `userrole` (
  `emailid` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL,
  `role` varchar(45) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY  USING BTREE (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userrole`
--

/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
